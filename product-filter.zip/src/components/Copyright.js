import React, { Component } from "react";
export default class Copyright extends Component {
  render() {
    return (
      <div>
        <h4>IMPORTANT LINKS</h4>
        <ul>
          <li>
            <a href="https://github.com/basir/ecommerce-shopping-cart">
              Download Source code{" "}
            </a>
          </li>
          <li>
            <a href="https://www.udemy.com/course/build-ecommerce-website-by-react-redux-in-one-hour/">
              Watch Learning Video
            </a>
          </li>{" "}
          <li>
            <a href="https://codingwithbasir.com/course/learn-react-redux/">
              Learn React From Scratch
            </a>
          </li>
        </ul>
      </div>
    );
  }
}
