import React from 'react';
import { Card } from 'react-bootstrap';
import { Button} from 'react-bootstrap';

const cardData = [
    {id: 123, imageUrl: "./productImage/shoe1.jpg", title: "Nike", price: 199, subtitle: "Lorem Ipsum is simply dummy text of the printing and typesetting industry."},
    {id: 456, imageUrl: "./productImage/shoe2.jpg", title: "Puma", price: 250, subtitle: "Lorem Ipsum is simply dummy text of the printing and typesetting industry."},
    {id: 789, imageUrl: "./productImage/shoe3.jpg", title: "Sparx", price: 300, subtitle: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.", }
];

class ProductCard extends React.Component {
    render () {
        return (
            cardData.map(item => (
                <div className="App" key={item.id}>
                    <Card style={{ width: "18rem" }}>
                        <Card.Img className="image" src={item.imageUrl} alt="product" />
                        <Card.Body>
                            <Card.Title className="title">{item.title}</Card.Title>
                            <Card.Subtitle className="price">${item.price}</Card.Subtitle>
                            <Card.Text className="sub-title">{item.subtitle}</Card.Text>
                            <Button variant="primary" className="button">Add To Cart</Button>
                        </Card.Body>
                    </Card>
                </div>
            ))
        )
    }
}

export default ProductCard;