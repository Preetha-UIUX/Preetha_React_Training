import React from 'react';
import ProductCard from './components/ProductCard';


class App extends React.Component {
  render () {
    return (
      <div className="product-card">
        <ProductCard />
      </div>
    )
  }
}

export default App;